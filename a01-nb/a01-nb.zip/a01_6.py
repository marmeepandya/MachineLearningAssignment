# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.7
#   kernelspec:
#     display_name: Python (ML25_assignments)
#     language: python
#     name: ml25
# ---

# %% [markdown]
# # 6 Preprocessing Features and Continuous Naive Bayes (optional)

# %%
import math
import numpy as np
import sklearn
# %load_ext autoreload
# %autoreload 2

from a01_helper import *


# %%
# YOUR CODE HERE
